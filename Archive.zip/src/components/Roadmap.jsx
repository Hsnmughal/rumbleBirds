import React from 'react'
import img_bottombannerfaq from "../images/hills__2.webp";

const Roadmap = () => {
  return (
    <>
      <div className="topFaqBanner">

      </div>

      <div>
        <img src={img_bottombannerfaq} alt="" 
          style={{width: "100%", height:"755px", objectFit:"cover", objectPosition:"50% 50%", maxHeight:"90vh"}}
        />
      </div>

    </>
  )
}

export default Roadmap